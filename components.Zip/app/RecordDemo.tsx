"use client";

import { useState } from "react";
import { DemoAppShell } from "./DemoAppShell";
import { DemoButton } from "./DemoButton";
import { CategoryIcon, CheckIcon, MicIcon } from "./AppIcons";

type RecordStep = "input" | "processing" | "confirm" | "saved";

export function RecordDemo() {
  const [step, setStep] = useState<RecordStep>("input");
  const [text, setText] = useState("오늘 이불 빨았어");
  const [action, setAction] = useState("이불 세탁");
  const [date, setDate] = useState("2026-09-03");
  const [item, setItem] = useState("이불 세탁");

  const isEmpty = text.trim().length === 0;
  const isTooLong = text.length > 500;
  const canAnalyze = !isEmpty && !isTooLong;
  const dateEmpty = date.trim().length === 0;
  const futureDate = date > "2026-09-03";
  const canSave = action.trim().length > 0 && !dateEmpty && !futureDate;

  return (
    <DemoAppShell activeRoute="record" title="기록하기">
      {step === "input" ? (
        <section className="space-y-5">
          <div>
            <h1 className="text-[26px] font-semibold leading-8">무엇을 했나요?</h1>
            <p className="mt-2 text-[14px] leading-6 text-[var(--muted)]">
              오늘 한 생활관리를 한 문장으로 남겨보세요.
            </p>
          </div>
          <label className="block text-[14px] font-semibold">
            기록할 내용
            <textarea
              className="focus-ring mt-2 min-h-48 w-full resize-none rounded-[24px] border-0 bg-white p-5 text-[17px] leading-7 shadow-[var(--shadow-card)]"
              onChange={(event) => setText(event.target.value)}
              placeholder="예) 오늘 이불 빨았어"
              value={text}
            />
          </label>
          <p
            className={[
              "rounded-2xl px-4 py-3 text-[13px] font-medium",
              isEmpty || isTooLong
                ? "bg-[#ffe2dc] text-[#9f3e30]"
                : "bg-[var(--mint)] text-[var(--primary-strong)]",
            ].join(" ")}
          >
            {isEmpty
              ? "내용을 입력하면 이해할 수 있어요."
              : isTooLong
                ? `500자를 넘었어요. ${text.length}/500자`
                : `${text.length}/500자 · 이해할 준비가 됐어요.`}
          </p>
          <button
            className="focus-ring flex min-h-16 w-full items-center justify-center gap-3 rounded-[22px] bg-white text-[15px] font-semibold shadow-[var(--shadow-card)]"
            onClick={() => setStep("processing")}
            type="button"
          >
            <span className="flex h-11 w-11 items-center justify-center rounded-full bg-[var(--mint)] text-[var(--primary)]">
              <MicIcon className="h-5 w-5" />
            </span>
            말로 기록하기
          </button>
          <DemoButton disabled={!canAnalyze} onClick={() => setStep("processing")} tone="primary">
            기록 이해하기
          </DemoButton>
        </section>
      ) : null}

      {step === "processing" ? (
        <section className="flex min-h-[58vh] flex-col items-center justify-center text-center">
          <div className="animate-lastly-pulse flex h-20 w-20 items-center justify-center rounded-[28px] bg-[var(--mint)] text-[var(--primary)]">
            <CategoryIcon category="생활" className="h-9 w-9" />
          </div>
          <h1 className="mt-6 text-[24px] font-semibold leading-8">
            LASTLY가 기록을 이해하고 있어요
          </h1>
          <p className="mt-3 text-[14px] leading-6 text-[var(--muted)]">
            잠시만 기다려주세요. 지금은 데모 화면에서 다음 확인 단계로 이어집니다.
          </p>
          <div className="mt-8 w-full space-y-2">
            <DemoButton onClick={() => setStep("confirm")} tone="primary">
              확인 화면 보기
            </DemoButton>
            <DemoButton onClick={() => setStep("input")} tone="ghost">
              다시 입력하기
            </DemoButton>
          </div>
        </section>
      ) : null}

      {step === "confirm" ? (
        <section className="space-y-5">
          <div className="rounded-[26px] bg-white p-5 shadow-[var(--shadow-card)]">
            <p className="text-[13px] font-medium text-[var(--muted)]">내가 말한 내용</p>
            <p className="mt-2 text-[20px] font-semibold leading-7">{text || "오늘 이불 빨았어"}</p>
          </div>
          <div className="rounded-[28px] bg-white p-5 shadow-[var(--shadow-card)]">
            <p className="text-[13px] font-medium text-[var(--muted)]">
              LASTLY가 이렇게 이해했어요
            </p>
            <div className="mt-4 flex items-center gap-3">
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[var(--mint)] text-[var(--primary)]">
                <CategoryIcon category="생활" className="h-6 w-6" />
              </span>
              <div>
                <span className="rounded-full bg-[var(--mint)] px-3 py-1 text-xs font-semibold text-[var(--primary-strong)]">
                  생활
                </span>
                <h1 className="mt-2 text-[24px] font-semibold">{action}</h1>
              </div>
            </div>
            <label className="mt-5 block text-[14px] font-semibold">
              수행한 날
              <input
                className="focus-ring mt-2 min-h-12 w-full rounded-2xl border-0 bg-[#f2f4ef] px-4"
                onChange={(event) => setDate(event.target.value)}
                type="date"
                value={date}
              />
            </label>
            <label className="mt-4 block text-[14px] font-semibold">
              어떤 항목으로 기록할까요?
              <select
                className="focus-ring mt-2 min-h-12 w-full rounded-2xl border-0 bg-[#f2f4ef] px-4"
                onChange={(event) => setItem(event.target.value)}
                value={item}
              >
                <option>이불 세탁</option>
                <option>침구 정리</option>
                <option>새 항목으로 기록</option>
              </select>
            </label>
            <label className="mt-4 block text-[14px] font-semibold">
              기록할 이름
              <input
                className="focus-ring mt-2 min-h-12 w-full rounded-2xl border-0 bg-[#f2f4ef] px-4"
                onChange={(event) => setAction(event.target.value)}
                value={action}
              />
            </label>
            {!canSave ? (
              <p className="mt-4 rounded-2xl bg-[#ffe2dc] px-4 py-3 text-[13px] font-semibold text-[#9f3e30]">
                {futureDate ? "미래 날짜는 완료기록으로 남길 수 없어요." : "수행한 날을 확인해주세요."}
              </p>
            ) : null}
          </div>
          <div className="grid grid-cols-2 gap-2">
            <DemoButton disabled={!canSave} onClick={() => setStep("saved")} tone="primary">
              기록하기
            </DemoButton>
            <DemoButton onClick={() => setStep("input")} tone="secondary">
              수정하기
            </DemoButton>
          </div>
        </section>
      ) : null}

      {step === "saved" ? (
        <section className="flex min-h-[60vh] flex-col items-center justify-center text-center">
          <div className="flex h-20 w-20 items-center justify-center rounded-[28px] bg-[var(--primary)] text-white shadow-[var(--shadow-card)]">
            <CheckIcon className="h-9 w-9" />
          </div>
          <h1 className="mt-6 text-[26px] font-semibold">기록했어요!</h1>
          <p className="mt-3 text-[18px] font-semibold">{item}</p>
          <p className="mt-2 text-[14px] text-[var(--muted)]">오늘 수행한 일로 데모 상태가 갱신됩니다.</p>
          <div className="mt-8 w-full space-y-2">
            <DemoButton href="/items" tone="primary">
              30일마다 관리
            </DemoButton>
            <DemoButton href="/" tone="secondary">
              홈으로
            </DemoButton>
          </div>
        </section>
      ) : null}
    </DemoAppShell>
  );
}
